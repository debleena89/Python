=======
Credits
=======

Development Lead
----------------

* Fernando Macedo <fgmacedo@gmail.com>

Contributors
------------

None yet. Why not be the first?


Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

