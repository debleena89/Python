=====
Usage
=====

To use Python State Machine in a project::

    import statemachine
